HRTMON.ROM 2.37 for MiST
http://www.whdload.de/whdload/Tools/

Compiled with vasm 1.8f
http://sun.hasenbraten.de/vasm/

Patch hrtmon_2.37_mist.patch:
-changes blk.l to dcb.l in src/disassemble.c for vasm
-configures HRTmon as cartridge ROM
-sets build date in version string (28.04.2019)
-fixes crash of reboot command


# lha x hrtmon237.lha
# cd hrtmon
# mv SPRfont.raw sprfont.raw
# patch -p1 < hrtmon_2.37_mist.patch
# cd src
# vasmm68k_mot -I/media/amigadevelopercd/NDK/NDK_3.1/Includes\&Libs/include_i -I.. -m68010 -Fbin -o HRTMON.ROM HRTmonV2.s


65796144f7956c2aeceb9d4559316f8b  HRTMON.ROM
